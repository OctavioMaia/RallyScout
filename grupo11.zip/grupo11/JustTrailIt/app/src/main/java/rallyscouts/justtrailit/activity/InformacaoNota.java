package rallyscouts.justtrailit.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import rallyscouts.justtrailit.R;

public class InformacaoNota extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gerir_atividade);
    }
}
